<?php

	$about = array(
		'name' => '',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad_micutul@yahoo.com',
		),
		'release-date' => '2011-05-23'
	);

	/**
	 * Field: Select Box Link
	 */
	$dictionary = array(

		'Select Box Link' => 
		'Select Box Link',

		'Values' => 
		'Valori',

		'Limit to the %s most recent entries' => 
		'Limitează la %s cele mai recente înregistrări',

		'Allow selection of multiple options' => 
		'Permite selectarea de opţiuni multiple',

	);
