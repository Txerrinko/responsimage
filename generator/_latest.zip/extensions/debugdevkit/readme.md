# Debug Devkit #

A debug panel for Symphony.
It is part of the Symphony core download package.

- Version: 1.2.1
- Date: 2011-07-03
- Requirements: Symphony 2.0.4 or later
- Author: Rowan Lewis, me@rowanlewis.com
- GitHub Repository: <http://github.com/rowan-lewis/debugdevkit>

## Usage

Append `?debug` to your front-end pages when logged in to initialise this Devkit.