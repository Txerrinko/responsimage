# Profile Devkit #

A profile panel for Symphony.
It is part of the Symphony core download package.

- Version: 1.0.4
- Date: 2010-03-19
- Requirements: Symphony 2.0.4 or later
- Author: Rowan Lewis, me@rowanlewis.com
- GitHub Repository: <http://github.com/rowan-lewis/profiledevkit>

## Usage

Append `?profile` to your front-end pages when logged in to initialise this Devkit.

## Change Log

**Version 1.0**

- Initial release