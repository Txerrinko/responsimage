<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => '',
			'email' => '',
			'website' => ''
		),
		'release-date' => '2011-05-19'
	);

	/**
	 * Mass Upload Utility
	 */
	$dictionary = array(


		'Successfully added a whole slew of entries, {$total} to be exact.' => false,
		'However, {$total} entries were successfully added.' => false,
		'Some errors were encountered while attempting to save.' => false,
		'View all Entries' => false,
		'Create more?' => false,
		'Sorry, but your browser is incompatible with uploading files using HTML5 (at least, with current preferences.\n Please install the latest version of Firefox, Safari or Chrome' => false,
		'Start' => false,
		'Progress' => false,
		'Loaded' => false,
		'Finished' => false,
		'multiple files can be selected, use the <code>shift</code> or <code>ctrl/cmd</code> key' => false


	);
